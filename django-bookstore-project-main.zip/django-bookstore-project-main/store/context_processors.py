from django.db.models import Sum
from .models import CartItem, Category


def cart_info(request):
    key = request.session.session_key
    count = 0
    if key:
        count = CartItem.objects.filter(session_key=key).aggregate(n=Sum("quantity"))["n"] or 0
    return {"cart_count": count, "nav_categories": Category.objects.all()}
