from django.contrib import admin
from .models import Book, Category, Order, OrderLine, Subscriber


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "icon", "slug")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "category", "price", "rating",
                    "is_best_seller", "is_new_arrival", "has_audiobook")
    list_filter = ("category", "is_best_seller", "is_new_arrival", "has_audiobook")
    list_editable = ("is_best_seller", "is_new_arrival", "has_audiobook")
    search_fields = ("title", "author")
    readonly_fields = ("ai_summary",)


@admin.register(Subscriber)
class SubscriberAdmin(admin.ModelAdmin):
    list_display = ("email", "subscribed_at")
    search_fields = ("email",)


class LineInline(admin.TabularInline):
    model = OrderLine
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "email", "total", "created_at")
    inlines = [LineInline]
