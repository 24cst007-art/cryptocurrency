from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("books/", views.book_list, name="books"),
    path("category/<slug:slug>/", views.book_list, name="category"),
    path("book/<int:pk>/", views.book_detail, name="detail"),
    path("book/<int:pk>/summary/", views.ai_summary, name="ai_summary"),
    path("cart/", views.cart, name="cart"),
    path("cart/add/<int:pk>/", views.add_to_cart, name="add_to_cart"),
    path("cart/update/<int:pk>/", views.cart_update, name="cart_update"),
    path("checkout/", views.checkout, name="checkout"),
    path("order/<int:pk>/done/", views.success, name="success"),
    path("subscribe/", views.subscribe, name="subscribe"),
]
