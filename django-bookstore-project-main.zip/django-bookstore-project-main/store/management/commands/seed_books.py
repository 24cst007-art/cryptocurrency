from decimal import Decimal
from django.core.management.base import BaseCommand
from store.models import Book, Category

CATS = {"Fiction": "bi-moon-stars", "Non-fiction": "bi-lightning-charge", "Education": "bi-mortarboard",
        "Tech": "bi-cpu", "Self-help": "bi-fire", "Sci-fi": "bi-rocket-takeoff"}

# title, author, category, price, rating, best, new, audio, description
BOOKS = [
    ("1984", "George Orwell", "Fiction", 299, 4.8, 1, 0, 1, "A dystopian classic about surveillance, truth and power."),
    ("The Alchemist", "Paulo Coelho", "Fiction", 249, 4.5, 1, 0, 1, "A shepherd chases his destiny across the desert."),
    ("To Kill a Mockingbird", "Harper Lee", "Fiction", 279, 4.7, 0, 0, 0, "Justice and growing up in the American South."),
    ("Sapiens", "Yuval Noah Harari", "Non-fiction", 399, 4.6, 1, 0, 1, "A brief history of humankind."),
    ("Educated", "Tara Westover", "Non-fiction", 349, 4.6, 0, 1, 0, "A memoir of breaking out through learning."),
    ("Atomic Habits", "James Clear", "Self-help", 450, 4.8, 1, 0, 1, "Tiny changes that compound into remarkable results."),
    ("Deep Work", "Cal Newport", "Self-help", 380, 4.4, 0, 1, 0, "Rules for focused success in a distracted world."),
    ("Clean Code", "Robert C. Martin", "Tech", 520, 4.6, 1, 0, 0, "A handbook of agile software craftsmanship."),
    ("Fluent Python", "Luciano Ramalho", "Tech", 650, 4.7, 0, 1, 0, "Clear, concise and effective Python programming."),
    ("Designing Data-Intensive Applications", "Martin Kleppmann", "Tech", 700, 4.8, 0, 1, 0, "The big ideas behind reliable, scalable systems."),
    ("Dune", "Frank Herbert", "Sci-fi", 420, 4.7, 1, 0, 1, "Politics, prophecy and spice on the desert planet Arrakis."),
    ("The Martian", "Andy Weir", "Sci-fi", 330, 4.6, 0, 1, 1, "One astronaut, one planet, zero rescue plans."),
    ("Neuromancer", "William Gibson", "Sci-fi", 310, 4.2, 0, 1, 0, "The cyberpunk novel that named cyberspace."),
    ("A Brief History of Time", "Stephen Hawking", "Education", 360, 4.5, 0, 0, 0, "From the Big Bang to black holes."),
    ("Thinking, Fast and Slow", "Daniel Kahneman", "Education", 410, 4.5, 0, 0, 1, "How two systems of thought drive our decisions."),
    ("The Pragmatic Programmer", "Hunt & Thomas", "Tech", 480, 4.6, 0, 1, 0, "Your journey to mastery."),
]


class Command(BaseCommand):
    help = "Load demo categories and books"

    def handle(self, *args, **opts):
        cats = {n: Category.objects.get_or_create(name=n, defaults={"icon": i})[0] for n, i in CATS.items()}
        for t, a, c, p, r, b, n, au, d in BOOKS:
            Book.objects.get_or_create(title=t, defaults=dict(
                author=a, category=cats[c], price=Decimal(p), rating=Decimal(str(r)),
                is_best_seller=bool(b), is_new_arrival=bool(n), has_audiobook=bool(au), description=d))
        self.stdout.write(self.style.SUCCESS(f"Loaded {Book.objects.count()} books."))
