from decimal import Decimal

from django.contrib import messages
from django.db.models import Q, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from . import gemini
from .models import Book, CartItem, Category, Order, OrderLine, Subscriber


def _key(request):
    if not request.session.session_key:
        request.session.create()
    return request.session.session_key


def _cart(request):
    items = list(CartItem.objects.filter(session_key=_key(request)).select_related("book"))
    total = sum((i.subtotal for i in items), Decimal("0"))
    return items, total


def home(request):
    return render(request, "store/home.html", {
        "best_sellers": Book.objects.filter(is_best_seller=True)[:8],
        "new_arrivals": Book.objects.filter(is_new_arrival=True)[:8],
        "audiobooks": Book.objects.filter(has_audiobook=True)[:4],
        "categories": Category.objects.all(),
        "book_count": Book.objects.count(),
    })


def book_list(request, slug=None):
    books = Book.objects.select_related("category")
    category = get_object_or_404(Category, slug=slug) if slug else None
    if category:
        books = books.filter(category=category)
    q = request.GET.get("q", "").strip()
    if q:
        books = books.filter(Q(title__icontains=q) | Q(author__icontains=q))
    sort = request.GET.get("sort", "new")
    order = {"price_asc": "price", "price_desc": "-price", "rating": "-rating"}.get(sort, "-created_at")
    return render(request, "store/books.html", {
        "books": books.order_by(order), "category": category, "q": q, "sort": sort,
        "categories": Category.objects.all(),
    })


def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    related = Book.objects.filter(category=book.category).exclude(pk=pk)[:4]
    return render(request, "store/detail.html", {"book": book, "related": related})


def ai_summary(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if not book.ai_summary:
        try:
            book.ai_summary = gemini.book_summary(book.title, book.author)
            book.save(update_fields=["ai_summary"])
        except Exception as exc:  # missing key, network, quota...
            return JsonResponse({"ok": False, "error": str(exc)}, status=502)
    return JsonResponse({"ok": True, "summary": book.ai_summary})


@require_POST
def add_to_cart(request, pk):
    book = get_object_or_404(Book, pk=pk)
    item, created = CartItem.objects.get_or_create(session_key=_key(request), book=book)
    if not created:
        item.quantity += 1
        item.save()
    count = CartItem.objects.filter(session_key=_key(request)).aggregate(n=Sum("quantity"))["n"]
    if request.headers.get("x-requested-with") == "fetch":
        return JsonResponse({"ok": True, "count": count, "title": book.title})
    messages.success(request, f"“{book.title}” added to cart.")
    return redirect(request.POST.get("next") or "cart")


def cart(request):
    items, total = _cart(request)
    return render(request, "store/cart.html", {"items": items, "total": total})


@require_POST
def cart_update(request, pk):
    item = get_object_or_404(CartItem, pk=pk, session_key=_key(request))
    action = request.POST.get("action")
    if action == "inc":
        item.quantity += 1
        item.save()
    elif action == "dec" and item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()
    return redirect("cart")


def checkout(request):
    items, total = _cart(request)
    if not items:
        return redirect("cart")
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip()
        address = request.POST.get("address", "").strip()
        if not (name and email and address):
            messages.error(request, "Fill in name, email and address to place the order.")
        else:
            order = Order.objects.create(name=name, email=email, address=address, total=total)
            OrderLine.objects.bulk_create([
                OrderLine(order=order, title=i.book.title, price=i.book.price, quantity=i.quantity) for i in items])
            CartItem.objects.filter(session_key=_key(request)).delete()
            return redirect("success", pk=order.pk)
    return render(request, "store/checkout.html", {"items": items, "total": total})


def success(request, pk):
    return render(request, "store/success.html", {"order": get_object_or_404(Order, pk=pk)})


@require_POST
def subscribe(request):
    email = request.POST.get("email", "").strip().lower()
    fetch = request.headers.get("x-requested-with") == "fetch"
    try:
        from django.core.validators import validate_email
        validate_email(email)
    except Exception:
        msg, ok = "That email doesn't look right. Check it and try again.", False
    else:
        _, created = Subscriber.objects.get_or_create(email=email)
        msg, ok = ("You're in. Watch your inbox." if created else "You're already subscribed."), True
    if fetch:
        return JsonResponse({"ok": ok, "message": msg})
    (messages.success if ok else messages.error)(request, msg)
    return redirect(request.META.get("HTTP_REFERER", "home"))
