"""Google Gemini (AI Studio) client using plain requests + JSON."""
import requests
from django.conf import settings

URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def book_summary(title, author):
    if not settings.GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not set. Add it to your .env file.")
    prompt = (f'Write a spoiler-free summary of the book "{title}" by {author} '
              "in 90-120 words. Plain text, no markdown, no headings.")
    resp = requests.post(
        URL.format(model=settings.GEMINI_MODEL),
        params={"key": settings.GEMINI_API_KEY},
        json={"contents": [{"parts": [{"text": prompt}]}]},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"].strip()
