from django.db import models
from django.db.models import Sum, F
from django.utils.text import slugify


class Category(models.Model):
    name = models.CharField(max_length=60, unique=True)
    slug = models.SlugField(unique=True, blank=True)
    icon = models.CharField(max_length=40, default="bi-book", help_text="Bootstrap Icons class, e.g. bi-rocket-takeoff")

    class Meta:
        verbose_name_plural = "categories"
        ordering = ["name"]

    def save(self, *a, **kw):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*a, **kw)

    def __str__(self):
        return self.name


class Book(models.Model):
    COLORS = [("#ff2d87", "#7b2ff7"), ("#19f0ff", "#0a3cff"), ("#ffd400", "#ff5b1f"),
              ("#ff5b1f", "#b8005c"), ("#7dff5a", "#00a88f"), ("#c77dff", "#3a0ca3")]
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=120)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="books")
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=4.0)
    cover_url = models.URLField(blank=True, help_text="Optional. Leave empty for a generated cover.")
    is_best_seller = models.BooleanField(default=False)
    is_new_arrival = models.BooleanField(default=False)
    has_audiobook = models.BooleanField(default=False, verbose_name="audiobook available")
    ai_summary = models.TextField(blank=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    @property
    def gradient(self):
        a, b = self.COLORS[self.pk % len(self.COLORS)] if self.pk else self.COLORS[0]
        return f"linear-gradient(145deg,{a},{b})"

    def __str__(self):
        return self.title


class Subscriber(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-subscribed_at"]

    def __str__(self):
        return self.email


class CartItem(models.Model):
    session_key = models.CharField(max_length=40, db_index=True)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ("session_key", "book")

    @property
    def subtotal(self):
        return self.book.price * self.quantity


class Order(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    address = models.TextField()
    total = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Order #{self.pk} - {self.name}"


class OrderLine(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="lines")
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    quantity = models.PositiveIntegerField()
