(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // cursor spotlight
  const sp = $('#spotlight');
  addEventListener('mousemove', e => { sp.style.left = e.clientX + 'px'; sp.style.top = e.clientY + 'px'; });

  // scroll reveal (staggered)
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .12 });
  $$('.reveal').forEach((el, i) => { el.style.transitionDelay = (i % 4) * 80 + 'ms'; io.observe(el); });

  // 3D tilt
  if (!reduce) $$('.tilt').forEach(el => {
    el.addEventListener('mousemove', e => {
      const r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      el.style.transform = `perspective(700px) rotateY(${x * 14}deg) rotateX(${-y * 14}deg) scale(1.03)`;
    });
    el.addEventListener('mouseleave', () => el.style.transform = '');
  });

  // toast
  let tt;
  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 2600);
  }

  // hero typewriter
  const typer = $('#typer');
  if (typer) {
    const lines = ['Books that hit back.', 'Stories with teeth.', 'AI summaries on every page.', 'Fresh drops every week.'];
    let li = 0, ci = 0, del = false;
    (function tick() {
      const s = lines[li];
      ci += del ? -1 : 1;
      typer.textContent = s.slice(0, ci);
      let d = del ? 35 : 70;
      if (!del && ci === s.length) { del = true; d = 1400; }
      else if (del && ci === 0) { del = false; li = (li + 1) % lines.length; d = 300; }
      setTimeout(tick, d);
    })();
  }

  // add to cart (fetch)
  $$('.add-form').forEach(f => f.addEventListener('submit', async e => {
    e.preventDefault();
    try {
      const r = await fetch(f.action, { method: 'POST', body: new FormData(f), headers: { 'x-requested-with': 'fetch' } });
      const d = await r.json();
      const c = $('#cartCount'); c.textContent = d.count; c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump');
      toast('⚡ Added: ' + d.title);
    } catch { f.submit(); }
  }));

  // newsletter
  const sf = $('#subForm');
  if (sf) sf.addEventListener('submit', async e => {
    e.preventDefault();
    const m = $('#subMsg');
    try {
      const d = await (await fetch(sf.action, { method: 'POST', body: new FormData(sf), headers: { 'x-requested-with': 'fetch' } })).json();
      m.textContent = d.message; m.style.color = d.ok ? 'var(--cyan)' : 'var(--pink)'; if (d.ok) sf.reset();
    } catch { m.textContent = 'Network error. Try again.'; m.style.color = 'var(--pink)'; }
  });

  // AI summary with typewriter
  const box = $('#aiBox');
  if (box && $('#aiBtn')) $('#aiBtn').addEventListener('click', async ev => {
    const btn = ev.currentTarget, txt = $('#aiText');
    btn.disabled = true; box.classList.add('loading'); txt.textContent = 'Reading the book…';
    try {
      const r = await fetch(box.dataset.url), d = await r.json();
      box.classList.remove('loading');
      if (!d.ok) { txt.textContent = 'Could not get a summary: ' + d.error; btn.disabled = false; return; }
      txt.textContent = ''; btn.remove();
      let i = 0; const t = setInterval(() => { i += 3; txt.textContent = d.summary.slice(0, i); if (i >= d.summary.length) clearInterval(t); }, 15);
    } catch { box.classList.remove('loading'); txt.textContent = 'Network error. Try again.'; btn.disabled = false; }
  });

  // confetti (order success)
  window.confetti = () => {
    if (reduce) return;
    const c = document.createElement('canvas'); c.className = 'confetti'; document.body.appendChild(c);
    const x = c.getContext('2d'); c.width = innerWidth; c.height = innerHeight;
    const cols = ['#ff2d87', '#19f0ff', '#ffd400', '#f6f0e4'];
    const ps = Array.from({ length: 160 }, () => ({ x: innerWidth / 2, y: innerHeight / 3, vx: (Math.random() - .5) * 18, vy: Math.random() * -16 - 4,
      s: 6 + Math.random() * 8, c: cols[Math.random() * 4 | 0], r: Math.random() * 6 }));
    let f = 0;
    (function draw() {
      x.clearRect(0, 0, c.width, c.height);
      ps.forEach(p => { p.vy += .35; p.x += p.vx; p.y += p.vy; p.r += .2; x.fillStyle = p.c; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillRect(-p.s / 2, -p.s / 2, p.s, p.s / 2); x.restore(); });
      if (++f < 200) requestAnimationFrame(draw); else c.remove();
    })();
  };
})();
