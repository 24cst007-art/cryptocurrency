from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "BookRiot Control Room"
admin.site.site_title = "BookRiot Admin"
admin.site.index_title = "Manage the chaos"

urlpatterns = [path("admin/", admin.site.urls), path("", include("store.urls"))]
