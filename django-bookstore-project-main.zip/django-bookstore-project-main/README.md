# BookRiot: Online Book Store (Django)

## Run it
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then paste your Gemini key (Windows: copy)
python manage.py makemigrations store
python manage.py migrate
python manage.py seed_books       # demo books + categories
python manage.py createsuperuser
python manage.py runserver
```
- Site: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

## Gemini AI summaries
Get a free key at https://aistudio.google.com/app/apikey and set `GEMINI_API_KEY` in `.env`.
Summaries are generated once per book, then cached in the database.

## Admin can manage
Books, categories, best seller / new arrival / audiobook flags (tick boxes right in the book list),
newsletter subscribers, and dummy orders.
